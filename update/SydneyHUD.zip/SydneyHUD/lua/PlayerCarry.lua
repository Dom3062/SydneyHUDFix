if SydneyHUD:GetOption("anti_bobble") then
	PlayerCarry.target_tilt = 0
end
